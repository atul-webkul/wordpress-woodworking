<?php
get_header();
?>

<div id="page">
			<div id="page-bgtop">
				<div id="page-bgbtm">
					<div id="content">
					<div class="notFound">
                        <p class="">Error No Page Found</p>
                    </div>
					</div>
					<!-- end #content -->
					<div style="clear: both;">&nbsp;</div>
				</div>
			</div>
		</div>

<?php
get_footer();
?>