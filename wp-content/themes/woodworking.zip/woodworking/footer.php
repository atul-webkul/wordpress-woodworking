		<!-- end #page -->
		<div id="footer">
			<p><?php the_field('copyright',18)?></p>
		</div>
		<!-- end #footer -->
	</div>
</div>
</body>
</html>
